# vale-wasm (prototype)

Minimal Rust WASM crate scaffold exposing `lint_text` compatible with the extension's `vale-native-bridge.js` expectations.

## Build
```
wasm-pack build --target web --release
```
Copy the generated `pkg/` folder into `chrome-extension/`.

## API
- `lint_text(text, rules_json)` -> JSON array of diagnostics.
- `lint(texts_json, rules_json)` -> JSON array of arrays for batch use.

Currently only processes an explicit JSON bundle form `{ "substitutions": [{ from, to, level? }, ...] }`.
When given the current raw YAML files map (`{ "files": { path: yamlString } }`) it returns an empty array (future: add YAML parsing in Rust).
