/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const lint_text: (a: number, b: number, c: number, d: number) => number;
export const lint: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_export_0: (a: number, b: number) => number;
export const __wbindgen_export_1: (a: number, b: number, c: number, d: number) => number;
